import PubSub from 'pubsub-js';
import request from '../../utils/request'
Page({

  /**
   * 页面的初始数据
   */
  data: {
      day:'',  // 天
      month:'',  //月
      recommendList: [],  //列表数据
    index:0,   //点击音乐的下标
  },

  /**
   * 生命周期函数--监听页面加载
   */
  
  async onLoad(options) {
    // 更日期的状态数据
    this.setData({
      day:new Date().getDate(),
      month:new Date().getMonth() + 1
    })
    // 获取每日推荐的数据
    // this.getRecommendList()
    // 订阅来自songdetil页面发布的消息
    // PubSub.subscribe('switchType',(msg,type)=>{
    //   let {recommendList,index} = this.data
      // console.log(msg,type)
      // if(type == 'pre'){ //点击的是上一首
      //   (index === 0) && (index = recommendList.length)
      //   index -= 1;
      // }else{  //点击的是下一首
      //   (index === recommendList.length -1) && (index = -1)
      //   index += 1
      // }
      // 更新动态的下标
      // this.setData({
      //   index
      // })
      // let musicId = recommendList[index].id
      // 将musicId回传给songdetail页面
  //     PubSub.publish('musicId',musicId)
  //   })
  // },
  // 获取每日用户推荐数据
  // async getRecommendList(){
  //   // 获取每日推荐的数据
  //   let result = await request("/recommend/songs")
  //   console.log(result,'获取每日推荐数据')
    // this.setData({
    //   recommendList:result.data.dailySongs
    // })
    let musicIdArr=[]
    var yid = wx.getStorageSync('yid')
    let recommendListdata= await request('/playlist/track/all',{id:yid,limit:20,offset:1},)
    this.setData({
      recommendList:recommendListdata.songs
    })
    for(let item of this.data.recommendList){
musicIdArr.push(item.al.id)
    }
    console.log(musicIdArr)
    console.log(this.data.recommendList)
// console.log(recommendListdata.data)
    
  },
  // 跳转至SongDetail页面
  toSongDetail(event){
    let rid =event.currentTarget.dataset.rid
    wx.navigateTo({
      url: '/pages/songDetail/songDetail?musicId='+rid
    })
    console.log(event)
    console.log('歌曲id'+rid)
  },
  // toSongDetail(event){
  //     let {song,index} = event.currentTarget.dataset
  //   this.setData({
  //     index
  //   })
    //   // 路由跳转传参
    // wx.navigateTo({
    //   // 不能直接将song对象作为参数传过去
    //   // url:'/page/songDetail/songDetail?song=' + JSON.stringify(song)
    //   url:'../songDetail/songDetail?musicId=' + song.id
    // })
// },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})
